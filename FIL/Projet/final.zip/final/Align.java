import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * Module align bas� sur l'algorithme d'alignement IBM1
 */
public class Align {
	private Tokenizer tokenizerS;
	private Tokenizer tokenizerT;
	private String trainS;
	private String trainT;
	private String output;
	
	private int nbIteration;
	private double EpsPrune;
	private int tailleLexiqueSource;
	private int tailleLexiqueCible;
	
	public Align(Tokenizer tknzS, String trainS, Tokenizer tknzT, String trainT, String output)// + 2 tokenizers, + 2 corpus + un nom output
	{
		nbIteration = 20;
		EpsPrune = 0.001;
		
		tokenizerS = tknzS;
		tokenizerT = tknzT;
		this.trainS = trainS;
		this.trainT = trainT;
		this.output = output;
		
		tailleLexiqueSource = tokenizerS.getLexiqueSize() + 1;
		tailleLexiqueCible = tokenizerT.getLexiqueSize() + 1;
	}
	
	public void setNbIteration(int nb)
	{
		nbIteration = nb;
	}
	
	public void setEpsPrune(double e)
	{
		EpsPrune = e;
	}
	
	public void run()
	{
		String trainScode = "corpus_ratp_bilang_en_code.txt";
		String trainTcode = "corpus_ratp_bilang_fr_code.txt";
		System.out.println("Tokenisation des corpus");
		tokenizerS.tokenize(trainS, trainScode);
		tokenizerT.tokenize(trainT, trainTcode);
		
		IBM1(trainScode, trainTcode, output);
	}
	
	public void IBM1(String inputE, String inputF, String output)
	{
		try 
		{
			//Initialisation uniforme de la table
			double PT[][] = new double[tailleLexiqueSource][tailleLexiqueCible];
			double pUniforme = 1.0 / (tailleLexiqueSource - 1); // nombre exact de tokens du lexique = tailleLexique - 1

			System.out.println("    IBM1 initialisation");
			//Initialisation de la matrice de probabilit�
			for(int j = 0; j < tailleLexiqueCible; j++)
			{
				for(int i = 0; i < tailleLexiqueSource; i++)
				{
					PT[i][j] = pUniforme;
				}
			}
			
			//Partie it�rative
			for(int numIte = 0; numIte < nbIteration; numIte++)
			{
				System.out.println("    IBM1 it�ration num�ro " + numIte);
				Scanner scE = new Scanner(new File(inputE));
				Scanner scF = new Scanner(new File(inputF));
				
				Scanner scStrE, scStrF;
				
				double nb[][] = new double[tailleLexiqueSource][tailleLexiqueCible];
				double total[] = new double[tailleLexiqueCible];
				
				String strE;
				String strF;
				int tokenE;
				int tokenF;
				
				while(scE.hasNextLine() && scF.hasNextLine())
				{
					double sTotal[] = new double[tailleLexiqueSource];//d�plac�
					strE = scE.nextLine();
					strF = scF.nextLine();
					
					scStrE = new Scanner(strE);
					while(scStrE.hasNextInt()) //Pour chaque mot ei de la phrase E
					{
						tokenE = scStrE.nextInt();
						sTotal[tokenE] = 0;
						
						scStrF = new Scanner(strF);
						while(scStrF.hasNextInt()) // Pour chaque mot fj de la phrase F
						{
							tokenF = scStrF.nextInt();
							sTotal[tokenE] += PT[tokenE][tokenF];
						}
						scStrF.close();
					}
					scStrE.close();
					
					scStrE = new Scanner(strE);
					while(scStrE.hasNextInt()) //Pour chaque mot ei de la phrase E
					{
						tokenE = scStrE.nextInt();
						
						scStrF = new Scanner(strF);
						while(scStrF.hasNextInt()) // Pour chaque mot fj de la phrase F
						{
							tokenF = scStrF.nextInt();
							double val = (PT[tokenE][tokenF] / sTotal[tokenE]);
							
							nb[tokenE][tokenF] += val;
							total[tokenF] += val;
						}
						scStrF.close();
					}
					scStrE.close();
					
				}
				
				//Pour tous les mot F (j 0 � taille lexique) // ou commencer � 2 direct
					//Pour tous les mot E (i 0 � taille lexique)
						//P ei, jf = nb(ei, fj) / total(fj)
				for(int j = 0; j < tailleLexiqueCible; j++)
				{
					for(int i = 0; i < tailleLexiqueSource; i++)
					{
						double p = nb[i][j] / total[j];
						if(p <= EpsPrune)
							p = 0;
						PT[i][j] = p;
					}
				}
				
				scE.close();
				scF.close();
			}
			//On �crit la table
			BufferedWriter bw = new BufferedWriter(new FileWriter(output));
			for(int i = 2; i < tailleLexiqueSource; i++)
			{
				for(int j = 2; j < tailleLexiqueCible; j++)
				{
					double p = PT[i][j];
					if(p > EpsPrune)//On �crit seulement les probabilit�s sup�rieure � EpsPrune
					{
						double lp = (-1) * Math.log10(p);
						String str = i + " " + j + " " + lp;
						bw.write(str);
						bw.newLine();
					}					
				}
			}
			bw.close();
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		
		if(args.length < 5)
		{
			System.out.println("Usage : Align lexiqueFR corpusFR lexiqueEN corpusEN output (nbIte) (EpsPrune)");
			System.exit(1);
		}
		String lexiqueFR = args[0];
		String corpusFR = args[1];
		String lexiqueEN = args[2];
		String corpusEN = args[3];
		String output = args[4];		
		
		System.out.println("Chargement des lexiques");
		Tokenizer tE = new Tokenizer(lexiqueEN);
		Tokenizer tF = new Tokenizer(lexiqueFR);
		
		System.out.println("Execution de l'algorithme IBM 1");
		Align align = new Align(tE, corpusEN, tF, corpusFR, output);
		
		if(args.length == 6)
		{
			int nbite = Integer.valueOf(args[5]);
			align.setNbIteration(nbite);
			
		}
		if(args.length == 7)
		{
			int nbite = Integer.valueOf(args[5]);
			align.setNbIteration(nbite);
			double epsprune = Double.valueOf(args[6]);
			align.setEpsPrune(epsprune);
		}
		
		align.run();
		System.out.println("Fichier " + output + " produit");
	}
}
