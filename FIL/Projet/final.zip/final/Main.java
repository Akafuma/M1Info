import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		//5 entr�es :
		// lexique FR
		// lexique EN
		// CORPUS BILANG FR
		// CORPUS BILANG EN
		// CORPUS FULL TRAIN FR
		if(args.length != 5)
		{
			System.out.println("Usage : Main lexiqueFR lexiqueEN corpusBilangFR corpusBilangEn corpusFullFR");
			System.exit(1);
		}
		String lexiqueFR = args[0];
		String lexiqueEN = args[1];
		String corpusBilangFR = args[2];
		String corpusBilangEN = args[3];
		String corpusFullFR = args[4];
		
		System.out.println("Initialisation...");
		
		Tokenizer tF = new Tokenizer(lexiqueFR);
		Tokenizer tE = new Tokenizer(lexiqueEN);
		
		String corpusFullFRCode = "corpusFullFR_code_tmp.txt";
		tF.tokenize(corpusFullFR, corpusFullFRCode);
		
		TokenCounter tc = new TokenCounter();
		String trainLM = "train_full_lm_tmp.txt";
		tc.count(corpusFullFRCode, trainLM);
		
		String tradENFR = "trad_en_fr_tmp.txt";
		Align align = new Align(tE, corpusBilangEN, tF, corpusBilangFR, tradENFR);
		align.run();
		
		LM lm = new LM();
		lm.load(trainLM);
		Trad trad = new Trad(tradENFR);
		
		Code2mot c2m = new Code2mot(lexiqueFR);
		String entry, output;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Initialisation termin�");
		System.out.println("----------------------");
		while(true)
		{

			entry = sc.nextLine();
			trad.writeTreillis(tE.tokenizeStr(entry), "treillis_tmp.txt");
			Treillis traducteur = new Treillis();
			traducteur.loadFromFile("treillis_tmp.txt");
			output = traducteur.viterbi(lm);
			
			System.out.println(c2m.runOnString(output));
		}
	}
}
