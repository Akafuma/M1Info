import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

/*
 * Compte les unigrammes et bigrammes d'un corpus tokenis� en produisant un fichier de compte
 */
public class TokenCounter {
	
	private String input;
	private String output;
	private Unigramme unigramme;
	private Bigramme bigramme;
	
	public TokenCounter() {
		unigramme = new Unigramme();
		bigramme = new Bigramme();
	}	
	
	public String getInput() {
		return input;
	}

	public String getOutput() {
		return output;
	}

	//Produit les comptes des 1-gram et 2-gram
	public void count(String filename, String nameoutput) // Attention au mots non reconnus par l'analyse lexicale
	{
		try
		{
			Scanner sc = new Scanner(new File(filename));
			
			input = filename;
			output = nameoutput;
			
			int num;
			int last;
			//Comptage bigramme et unigramme
			while(sc.hasNextLine())
			{
				String str = sc.nextLine();
				Scanner sc_str = new Scanner(str);
				
				num = sc_str.nextInt();
				unigramme.incr(num);
							
				last = num;
				
				while(sc_str.hasNextInt())
				{
					num = sc_str.nextInt();
					unigramme.incr(num);
					bigramme.incr(last, num);
					last = num;
				}				
				sc_str.close();
			}
			
			sc.close();
			
			//Ecriture du fichier
			BufferedWriter bw = new BufferedWriter(new FileWriter(nameoutput));
			bw.write("1-gram:");
			bw.newLine();
			for(int i = 0; i < unigramme.size(); i++)
			{
				if(unigramme.getCount(i) > 0)
				{
					String str = unigramme.indexToString(i);
					bw.write(str);
					bw.newLine();
				}
			}
			
			bw.write("2-gram:");
			bw.newLine();
			for(int i = 0; i < bigramme.size(); i++)
			{
				Vector<BigrammeElement> v = bigramme.getBigrammes(i);
				if(v != null)
				{
					for(int j = 0; j < v.size(); j++)
					{
						BigrammeElement e = v.get(j);
						String str = e.getNumToken1() + " " + e.getNumToken2() + " " + e.getCount();
						bw.write(str);
						bw.newLine();
					}
				}
			}
			
			bw.close();
		}		
		catch(FileNotFoundException e)
		{
			System.out.println(e);
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}	
	
	public static void main(String[] args) {
		if(args.length != 2)
		{
			System.out.println("Usage : TokenCounter corpus.code output");
			System.exit(1);
		}
		
		String input = args[0];
		String output = args[1];
		
		TokenCounter tc = new TokenCounter();
		System.out.println("Production du mod�le de langage du corpus tokenis� : " + input);
		tc.count(input, output);
		System.out.println("Fichier " + output + " produit");
	}
	
}
