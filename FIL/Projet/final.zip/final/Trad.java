import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;
import java.util.Vector;

/*
 * Charge une table de traduction en m�moire
 * Permet d'�crire le treillis d'une chaine tokenis� en argument
 */
public class Trad {

	private Vector<Vector<TradElement> > data;
	
	class TradElement {
		private int tokenS;
		private int tokenT;
		private double logprob;
		
		public TradElement(int tS, int tT, double p)
		{
			tokenS = tS;
			tokenT = tT;
			logprob = p;
		}
		
		public int getTokenS()
		{
			return tokenS;
		}
	}
	
	//charge la table de traduction
	public Trad(String filename)
	{
		try
		{
			//initialisation
			int maxTokenS = 0;
			Scanner sc = new Scanner(new File(filename));
			while(sc.hasNextLine())
			{
				maxTokenS = sc.nextInt(); 	//on lit le premier entier sur une ligne
				sc.nextLine();				//on saute une ligne
			}
			sc.close();
			
			data = new Vector< Vector<TradElement>>(maxTokenS + 1); //on veut pouvoir adresser l'indice maxTokenS, donc +1
			data.setSize(maxTokenS + 1);
			for(int i = 0; i < data.size(); i++)
			{
				Vector<TradElement> v = new Vector<TradElement>();
				data.setElementAt(v, i);
			}
			
			//chargement des donn�es
			int tokenS, tokenT;
			double lp;
			sc = new Scanner(new File(filename));
			String str;
			while(sc.hasNextLine())
			{
				str = sc.nextLine();
				
				Scanner sc_str = new Scanner(str);
				sc_str.useLocale(Locale.US);//pour lire les double correctement
				
				tokenS = sc_str.nextInt();
				tokenT = sc_str.nextInt();
				lp = sc_str.nextDouble();
				
				sc_str.close();

				TradElement e = new TradElement(tokenS, tokenT, lp);
				Vector<TradElement> v = data.get(tokenS);
				v.add(e);
			}
			sc.close();
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
	
	public void writeTreillis(String str, String output)//str tokenis� avec un lexique source
	{
		try
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter(output));
			Scanner sc = new Scanner(str);
			int token;
			int col = 0;
			String s;
			
			while(sc.hasNextInt())
			{
				s = "%col " + col;
				bw.write(s);
				bw.newLine();
				token = sc.nextInt();
				
				Vector<TradElement> v = data.get(token);
				for(int i = 0; i < v.size(); i++)
				{
					TradElement e = v.get(i);
					s = e.tokenT + " " + e.logprob;
					bw.write(s);
					bw.newLine();
				}
				col++;
			}
			sc.close();
			bw.close();
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
}
