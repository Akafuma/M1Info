import java.util.Scanner;

public class Traducteur {
	public static void main(String[] args) {
		if(args.length != 4)
		{
			System.out.println("Usage : Traducteur modeleLangage tableTraduction lexiqueFR lexiqueEN");
			System.exit(1);
		}
		
		String trainLM = args[0];
		String tableTrad = args[1];
		String lexiqueFR = args[2];
		String lexiqueEN = args[3];
		
		LM lm = new LM();
		lm.load(trainLM);
		Trad trad = new Trad(tableTrad);
		
		Tokenizer tE = new Tokenizer(lexiqueEN);
		Code2mot c2m = new Code2mot(lexiqueFR);
		String entry, output;
		Scanner sc = new Scanner(System.in);
		
		while(true)
		{

			entry = sc.nextLine();
			trad.writeTreillis(tE.tokenizeStr(entry), "treillis_tmp.txt");
			Treillis traducteur = new Treillis();
			traducteur.loadFromFile("treillis_tmp.txt");
			output = traducteur.viterbi(lm);
			
			System.out.println(c2m.runOnString(output));
		}
		
	}
}
